package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.eduOccupation;
import com.prs.model.personalInfo;
import com.prs.model.persistence.HibernateUtil;

public class eduoccupationDB {
	
	public Integer listeduoccupationid(String personalid) {
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();

        Transaction tx = null;
        List<Integer> CodeList;

        try {
            tx = session.getTransaction();
            tx.begin();
            CodeList = (List<Integer>) session.createSQLQuery("Select ideduoccupation FROM eduoccupation where personalinfoid=" + "\'" + personalid + "\'").list();
            tx.commit();
            if (CodeList.size() > 0) {
                return CodeList.get(0);
            }

        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } catch (NullPointerException ne) {
            ne.printStackTrace();
        } finally {
            session.close();
        }
        return null;

    }
	
	
	public eduOccupation geteduoccupation(String personalid)
    {
        
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();
        
        eduOccupation eduoccup = null;
        
        try{
        	Integer ideduoccupation=listeduoccupationid(personalid);
            eduoccup=(eduOccupation)session.get(eduOccupation.class, ideduoccupation);
	       }
        
        catch(NullPointerException ne)
        
	      {ne.printStackTrace();}
        
        catch(Exception sqlException) {
            if(null != session.getTransaction()) {
                System.out.println("\n.......Transaction Is Being Rolled Back.......");
                session.getTransaction().rollback();
            }
            sqlException.printStackTrace();
        }
        
        finally {
	      
        if(session != null) {
            session.close();
        }
        }
	       
        
        return eduoccup;
        
        
    }

}
