package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class symptomDB {

	public List<String> listSymptom() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<String> symptomlist;

		try {
			tx = session.getTransaction();
			tx.begin();
			symptomlist = (List<String>) session
					.createSQLQuery("Select symptom  FROM symptoms").list();
			tx.commit();
			if (symptomlist.size() > 0) {
				return symptomlist;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		return null;

	}

}
