package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class pharmaDB {
	
	
	public List<String> listPharma() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<String> pharmalist;

		try {
			tx = session.getTransaction();
			tx.begin();
			pharmalist = (List<String>) session
					.createSQLQuery("Select pharmacompany FROM pharmacompanies order by pharmacompany").list();
			tx.commit();
			if (pharmalist.size() > 0) {
				return pharmalist;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		return null;

	}

}
