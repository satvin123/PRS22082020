package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class disorderDB {
	
	
	public List<String> listDisorder()
	   {
	       SessionFactory factory = HibernateUtil.getSessionFactory();       
	        Session session=factory.openSession();


	Transaction tx = null;
	      List<String> disorderlist;
	      
	      try{
	         tx = session.getTransaction();
	         tx.begin();
	         disorderlist =(List<String>) session.createSQLQuery("Select disordername  FROM disorder order by disordername").list(); 
	         tx.commit();
	         if(disorderlist.size()>0)
	         {
	            return disorderlist;
	         }
	         
	         
	        
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }
	      catch(NullPointerException ne)
	          
	      {ne.printStackTrace();}
	      finally {
	         session.close(); 
	      }
	       return null;
	      
	   }
	
	
	
	

}
