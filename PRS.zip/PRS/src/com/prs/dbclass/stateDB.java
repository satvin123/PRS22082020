package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class stateDB {
	
	public List<String> listState()
	   {
	       
		SessionFactory  factory = HibernateUtil.getSessionFactory();       
	    Session session=factory.openSession();

	Transaction tx = null;
	      List<String> statelist;
	      
	      try{
	         tx = session.getTransaction();
	         tx.begin();
	         statelist =(List<String>) session.createSQLQuery("Select distinct state FROM city order by state").list(); 
	         tx.commit();
	         if(statelist.size()>0)
	         {
	             return statelist;
	         }
	         
	         
	        
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }
	      catch(NullPointerException ne)
	          
	      {ne.printStackTrace();}
	      finally {
	         session.close(); 
	      }
	       return null;
	      
	   }

}
