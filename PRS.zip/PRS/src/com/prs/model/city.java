package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "city")
public class city {
	
	@Id @GeneratedValue
	   @Column(name = "idcity")
	   private int id;

	   @Column(name = "country")
	   private String country;

	   @Column(name = "state")
	   private String state;

	   @Column(name = "cityname")
	   private String cityname;  

	   public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public city() {}
	
	

}
