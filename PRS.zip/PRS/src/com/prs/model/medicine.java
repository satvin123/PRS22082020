package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "medicine")
public class medicine {
	
	
	@Id @GeneratedValue
	   @Column(name = "idmedicine")
	   private int id;

	   @Column(name = "medicinename")
	   private String medicinename;

	   @Column(name = "medicinesalt")
	   private String medicinesalt;
	   
	   public medicine() {
		super();
	}

	@Column(name = "pharmacompany")
	   private String pharmacompany;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMedicinename() {
		return medicinename;
	}

	public void setMedicinename(String medicinename) {
		this.medicinename = medicinename;
	}

	public String getMedicinesalt() {
		return medicinesalt;
	}

	public void setMedicinesalt(String medicinesalt) {
		this.medicinesalt = medicinesalt;
	}

	public String getPharmacompany() {
		return pharmacompany;
	}

	public void setPharmacompany(String pharmacompany) {
		this.pharmacompany = pharmacompany;
	} 

}
