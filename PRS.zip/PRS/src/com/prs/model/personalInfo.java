package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "personalinfo")
public class personalInfo {
	
	public personalInfo() {
		super();
	}

	@Id @GeneratedValue
	   @Column(name = "idpersonalinfo")
	   private int id;
	
	@Column(name = "personalinfoid")
	   private String personalinfoid;
	
	@Column(name = "fname")
	   private String fname;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPersonalinfoid() {
		return personalinfoid;
	}

	public void setPersonalinfoid(String personalinfoid) {
		this.personalinfoid = personalinfoid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	@Column(name = "lname")
	   private String lname;
	
	@Column(name = "dob")
	   private String DOB;
	
	@Column(name = "gender")
	   private String gender;
	
	@Column(name = "relation")
	   private String relation;
	
	@Column(name = "rname")
	   private String rname;
	
	@Column(name = "married")
	   private String married;
	
	@Column(name = "age")
	   private String age;
	
	

}




	
	


