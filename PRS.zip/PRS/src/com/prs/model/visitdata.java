package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "visitdata")
public class visitdata {
	
	@Id @GeneratedValue
	   @Column(name = "idvisitdata")
	   private int id;

	   @Column(name = "visitno")
	   private String visitno;
	   
	   @Column(name = "patientid")
	   private String patientid;
	   
	   @Column(name = "dateofvisit")
	   private String dateofvisit;
	   
	   @Column(name = "shorthistory", length=65535)
	   @Type(type="text")
	   private String shorthistory;
	   
	   @Column(name = "complaints", length=65535)
	   @Type(type="text")
	   private String complaints;
	   
	   @Column(name = "findings", length=65535)
	   @Type(type="text")
	   private String findings;
	   
	   @Column(name = "bp")
	   private String bp;
	   
	   @Column(name = "pulse")
	   private String pulse;
	   
	   @Column(name = "respiration")
	   private String respiration;
	   
	   @Column(name = "temperature")
	   private String temperature;
	   
	   @Column(name = "painstatus")
	   private String painstatus;
	   
	   @Column(name = "nutritional")
	   private String nutritional;
	   
	   @Column(name = "treatment", length=65535)
	   @Type(type="text")
	   private String treatment;
	   
	   @Column(name = "investigation", length=65535)
	   @Type(type="text")
	   private String investigation;
	   
	   @Column(name = "lstsymptoms", length=65535)
	   @Type(type="text")
	   private String lstsymptoms;
	   
	   @Column(name = "lstdisorders", length=65535)
	   @Type(type="text")
	   private String lstdisorders;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVisitno() {
		return visitno;
	}

	public void setVisitno(String visitno) {
		this.visitno = visitno;
	}

	public String getPatientid() {
		return patientid;
	}

	public void setPatientid(String patientid) {
		this.patientid = patientid;
	}

	public String getDateofvisit() {
		return dateofvisit;
	}

	public void setDateofvisit(String dateofvisit) {
		this.dateofvisit = dateofvisit;
	}

	public String getShorthistory() {
		return shorthistory;
	}

	public void setShorthistory(String shorthistory) {
		this.shorthistory = shorthistory;
	}

	public String getComplaints() {
		return complaints;
	}

	public void setComplaints(String complaints) {
		this.complaints = complaints;
	}

	public String getFindings() {
		return findings;
	}

	public void setFindings(String findings) {
		this.findings = findings;
	}

	public String getBp() {
		return bp;
	}

	public void setBp(String bp) {
		this.bp = bp;
	}

	public String getPulse() {
		return pulse;
	}

	public void setPulse(String pulse) {
		this.pulse = pulse;
	}

	public String getRespiration() {
		return respiration;
	}

	public void setRespiration(String respiration) {
		this.respiration = respiration;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getPainstatus() {
		return painstatus;
	}

	public void setPainstatus(String painstatus) {
		this.painstatus = painstatus;
	}

	public String getNutritional() {
		return nutritional;
	}

	public void setNutritional(String nutritional) {
		this.nutritional = nutritional;
	}

	public String getTreatment() {
		return treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

	public String getInvestigation() {
		return investigation;
	}

	public void setInvestigation(String investigation) {
		this.investigation = investigation;
	}

	public String getLstsymptoms() {
		return lstsymptoms;
	}

	public void setLstsymptoms(String lstsymptoms) {
		this.lstsymptoms = lstsymptoms;
	}

	public String getLstdisorders() {
		return lstdisorders;
	}

	public void setLstdisorders(String lstdisorders) {
		this.lstdisorders = lstdisorders;
	}

	public visitdata() {
		super();
	}
	   
	  
	
	
	

}
