package com.prs.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.prs.model.prescription;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.log.Logger;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.prs.dbclass.prescriptionDB;
import com.prs.dclass.pdfgenmodel;

/**
 * Servlet implementation class PDFServlet
 */
@WebServlet("/PDFServlet")
public class PDFServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PDFServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/pdf");
		try  {

			Document document = new Document(PageSize.A4);

			try {
				 File file = new File("/home/satvinso/pdfhome/prescription.pdf");
				//File file = new File("C:\\project\\prescription.pdf");
				PdfWriter pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(file));
				document.open();
				 Image img11 = Image.getInstance("/home/satvinso/pdfhome/logo.png");
			//	Image img11 = Image.getInstance("C:\\project\\logo.png");
				img11.scaleAbsolute(95, 65);
				document.add(img11);

				PdfContentByte canvas = pdfWriter.getDirectContent();
				// Rectangle rect = new Rectangle(110, 815, 557, 740);
				// rect.setBackgroundColor(BaseColor.LIGHT_GRAY);
				// canvas.rectangle(rect);

				pdfgenmodel.FixTextBold("Dr. Vaibhav Dubey", 200, 790, pdfWriter, 14);
				pdfgenmodel.FixText("MBBS, MD (Psychiatry)", 200, 778, pdfWriter, 12);
				pdfgenmodel.FixText("Clinic Between Polytechnic Square and Kilol Park Petrol Pump", 200, 766, pdfWriter,
						12);
				pdfgenmodel.FixText("Near Angithi Restaurant, Bhopal- 462002 MP (India)", 200, 754, pdfWriter, 12);
				pdfgenmodel.FixText("Mobile- +91 9424401688 E-mail - dr.vaibhavdubey@gmail.com", 200, 743, pdfWriter,
						12);
				pdfgenmodel.FixTextBold(
						"____________________________________________________________________________________", 200,
						743, pdfWriter, 12);

				pdfgenmodel.FixTextBold("Medical Prescription ", 250, 723, pdfWriter, 12);
				pdfgenmodel.FixTextBold("____________________", 250, 721, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Date : "+request.getParameter("dateofvisit"), 445, 723, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Patient Name : ", 30, 690, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("patientname"), 110, 690, pdfWriter, 10);
				pdfgenmodel.FixTextBold(" : " + request.getParameter("patientrelation") + " : ", 195, 690, pdfWriter,
						12);
				pdfgenmodel.FixText(request.getParameter("relativename"), 240, 690, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Age : ", 362, 690, pdfWriter,12);
				pdfgenmodel.FixText(request.getParameter("patientage"), 390, 690, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Gender : ", 445, 690, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("patientgender"), 500, 690, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Address : ", 30, 670, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("address"), 85, 670, pdfWriter, 10);
				pdfgenmodel.FixTextBold("City : ", 255, 670, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("city"), 300, 670, pdfWriter, 10);
				pdfgenmodel.FixTextBold("State : ", 350, 670, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("state"), 395, 670, pdfWriter,10);
				pdfgenmodel.FixTextBold("Mobile No : ", 30, 650, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("mobileno"), 100, 650, pdfWriter, 10);
				pdfgenmodel.FixTextBold("E-Mail Id : ", 180, 650, pdfWriter, 12);
				pdfgenmodel.FixText(request.getParameter("emailid"), 250, 650, pdfWriter, 10);
				pdfgenmodel.FixTextBold("Personal Id : ", 355, 650, pdfWriter, 12);
				
				
				pdfgenmodel.FixText(request.getParameter("patientid"), 425, 650, pdfWriter, 10);
				float[] columnWidths = { 3, 10 };
				
				
				
				PdfPTable table11 = new PdfPTable(columnWidths);
				table11.setWidthPercentage(100);
				
				FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");
				//FontFactory.register("C:\\project\\Cambria.ttf", "Greek-Regular");
				Font f = FontFactory.getFont("Greek-Regular", 12);
				Font f1 = FontFactory.getFont("Greek-Regular", 12, Font.BOLD);
				//;

				PdfPCell cell211 = new PdfPCell(new Paragraph("Short History", f1));
				PdfPCell cell212 = new PdfPCell(new Paragraph(request.getParameter("shorthistory"), f));

				table11.addCell(cell211);
				table11.addCell(cell212);

				table11.setSpacingBefore(110);
				table11.setHeaderRows(0);
				document.add(table11);
				
				
				PdfPTable table21 = new PdfPTable(columnWidths);
				table21.setWidthPercentage(100);
				//FontFactory.register("c:\\project\\cambria.ttf", "Greek-Regular");
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");

				PdfPCell cell221 = new PdfPCell(new Paragraph("Complaints", f1));
				PdfPCell cell222 = new PdfPCell(new Paragraph(request.getParameter("complaints"), f));

				table21.addCell(cell221);
				table21.addCell(cell222);

				table21.setSpacingBefore(3);
				table21.setHeaderRows(0);
				document.add(table21);
				
				PdfPTable table31 = new PdfPTable(columnWidths);
				table31.setWidthPercentage(100);
				//FontFactory.register("c:\\project\\cambria.ttf", "Greek-Regular");
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");

				PdfPCell cell231 = new PdfPCell(new Paragraph("Findings", f1));
				PdfPCell cell232 = new PdfPCell(new Paragraph(request.getParameter("findings"), f));

				table31.addCell(cell231);
				table31.addCell(cell232);

				table31.setSpacingBefore(3);
				table31.setHeaderRows(0);
				
				document.add(table31);
				
				
				
				
				
				
				
				
				
				
				
				
				PdfPTable table = new PdfPTable(columnWidths);
				table.setWidthPercentage(100);
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");
				
				PdfPCell cell1 = new PdfPCell(new Paragraph("Treatment Advised", f1));
				PdfPCell cell2 = new PdfPCell(new Paragraph(request.getParameter("treatment"), f));

				table.addCell(cell1);
				table.addCell(cell2);

				table.setSpacingBefore(3);
				table.setHeaderRows(0);

				PdfPTable table1 = new PdfPTable(columnWidths);
				table1.setWidthPercentage(100);
				//FontFactory.register("c:\\project\\cambria.ttf", "Greek-Regular");
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");

				PdfPCell cell3 = new PdfPCell(new Paragraph("Investigation Advised / Reference", f1));
				PdfPCell cell4 = new PdfPCell(new Paragraph(request.getParameter("investigation"), f));

				table1.addCell(cell3);
				table1.addCell(cell4);

				table1.setSpacingBefore(3);
				table1.setHeaderRows(0);
				
				
				PdfPTable table41 = new PdfPTable(columnWidths);
				table41.setWidthPercentage(100);
				//FontFactory.register("c:\\project\\cambria.ttf", "Greek-Regular");
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");

				PdfPCell cell241 = new PdfPCell(new Paragraph("Major Symptoms", f1));
				PdfPCell cell242 = new PdfPCell(new Paragraph(request.getParameter("symptoms12"), f));

				table41.addCell(cell241);
				table41.addCell(cell242);

				table41.setSpacingBefore(3);
				table41.setHeaderRows(0);
				
				
				
				PdfPTable table51 = new PdfPTable(columnWidths);
				table51.setWidthPercentage(100);
				//FontFactory.register("c:\\project\\cambria.ttf", "Greek-Regular");
				
				//FontFactory.register("/home/satvinso/pdfhome/Cambria.ttf", "Greek-Regular");

				PdfPCell cell251 = new PdfPCell(new Paragraph("Major Disorders", f1));
				PdfPCell cell252 = new PdfPCell(new Paragraph(request.getParameter("disorders12"), f));

				table51.addCell(cell251);
				table51.addCell(cell252);

				table51.setSpacingBefore(3);
				table51.setHeaderRows(0);
				
				
				
				
				
				
				
				
				
				float[] columnWidths1 = { 4, 4, 3, 5, 3, 5 };
				
				PdfPTable table2 = new PdfPTable(columnWidths1);
				
				PdfPCell cell11 = new PdfPCell(new Paragraph("BP", f1));
				PdfPCell cell12 = new PdfPCell(new Paragraph(request.getParameter("BP"), f));
				PdfPCell cell13 = new PdfPCell(new Paragraph("Pulse", f1));
				PdfPCell cell14 = new PdfPCell(new Paragraph(request.getParameter("pulse"), f));
				PdfPCell cell15 = new PdfPCell(new Paragraph("Respiration", f1));
				PdfPCell cell16 = new PdfPCell(new Paragraph(request.getParameter("respiration"), f));
				
				PdfPCell cell21 = new PdfPCell(new Paragraph("Temperature", f1));
				PdfPCell cell22 = new PdfPCell(new Paragraph(request.getParameter("temperature"), f));
				PdfPCell cell23 = new PdfPCell(new Paragraph("Pain Status", f1));
				PdfPCell cell24 = new PdfPCell(new Paragraph(request.getParameter("painstatus"), f));
				PdfPCell cell25 = new PdfPCell(new Paragraph("Nutritional Status", f1));
				PdfPCell cell26 = new PdfPCell(new Paragraph(request.getParameter("nutritional"), f));
				
				table2.addCell(cell11);
				table2.addCell(cell12);
				table2.addCell(cell13);
				table2.addCell(cell14);
				table2.addCell(cell15);
				table2.addCell(cell16);
				table2.addCell(cell21);
				table2.addCell(cell22);
				table2.addCell(cell23);
				table2.addCell(cell24);
				table2.addCell(cell25);
				table2.addCell(cell26);
				
				table2.setSpacingBefore(5);
				table2.setWidthPercentage(100);

				document.add(table);
				document.add(table1);
				document.add(table2);
				document.add(table41);
				document.add(table51);
				
				
				
				String personalid=request.getParameter("patientid");
				System.out.println("satvinder  ---"+personalid);
				String visitno=request.getParameter("visitno");
				System.out.println("satvinder  ---"+visitno);
			    
				prescriptionDB medicine = new prescriptionDB();
				List<prescription> medicines = (List<prescription>) medicine.listMedicines(personalid, visitno);
				Iterator<prescription> medicine1 = medicines.iterator();
				float[] columnWidths2 = { 1, 6, 2, 3 };
				PdfPTable table3 = new PdfPTable(columnWidths2);
				table3.setSpacingBefore(5);
				table3.setWidthPercentage(100);
				PdfPCell cell111 = new PdfPCell(new Paragraph("SNo", f1));
				PdfPCell cell112 = new PdfPCell(new Paragraph("Medicine", f1));
				PdfPCell cell113 = new PdfPCell(new Paragraph("Dosage", f1));
				PdfPCell cell114 = new PdfPCell(new Paragraph("Prescribed Time", f1));
				table3.addCell(cell111);
				table3.addCell(cell112);
				table3.addCell(cell113);
				table3.addCell(cell114);
				while (medicine1.hasNext()) {
				prescription medicine12=medicine1.next();
				PdfPCell cell121 = new PdfPCell(new Paragraph(medicine12.getSno(), f));
				PdfPCell cell122 = new PdfPCell(new Paragraph(medicine12.getMedicinename(), f));
				PdfPCell cell123 = new PdfPCell(new Paragraph(medicine12.getDosage(), f));
				PdfPCell cell124 = new PdfPCell(new Paragraph(medicine12.getPresctime(), f));
				table3.addCell(cell121);
				table3.addCell(cell122);
				table3.addCell(cell123);
				table3.addCell(cell124);		
				
				}
				
				
				document.add(table3);
				

				document.close();
				
				String pdfFileName = "prescription.pdf";
				String contextPath = getServletContext().getRealPath(File.separator);
				File pdfFile = new File("/home/satvinso/pdfhome/prescription.pdf");
				//File pdfFile = new File("C:\\project\\prescription.pdf");

				
				response.addHeader("Content-Disposition", "attachment; filename=" + pdfFileName);
				response.setContentLength((int) pdfFile.length());

				FileInputStream fileInputStream = new FileInputStream(pdfFile);
				OutputStream responseOutputStream = response.getOutputStream();
				int bytes;
				while ((bytes = fileInputStream.read()) != -1) {
					responseOutputStream.write(bytes);
				}
				
				

			} catch (DocumentException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}finally {}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
