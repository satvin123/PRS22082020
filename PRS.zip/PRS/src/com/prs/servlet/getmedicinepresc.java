package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.contactDB;
import com.prs.dbclass.medicineprescDB;
import com.prs.dbclass.personalInfoDB;
import com.prs.dbclass.visitdataDB;
import com.prs.model.contact;
import com.prs.model.medicinepresc;
import com.prs.model.personalInfo;
import com.prs.model.visitdata;

/**
 * Servlet implementation class getmedicinepresc
 */
@WebServlet("/getmedicinepresc")
public class getmedicinepresc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getmedicinepresc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");

		String searchtextsd = request.getParameter("searchtextsd");
		  
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		Date date1 = null;
		Date date2 = null;
		try {
			 date1=new SimpleDateFormat("yyyy-MM-dd").parse(startdate);
			 
			 date2=new SimpleDateFormat("yyyy-MM-dd").parse(enddate);
			 
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
		String strDate = dateFormat.format(date1);
		String endDate = dateFormat.format(date2);
		
		medicineprescDB searchinfodb = new medicineprescDB();
		List<medicinepresc> searchlist = searchinfodb.listmedicinepresc(searchtextsd, strDate, endDate);

		medicinepresc medpresc;
		personalInfo pi;
		personalInfoDB personal = new personalInfoDB();
		contactDB contactdb=new contactDB();
		
		contact con;
		try (PrintWriter out = response.getWriter()) {
			/* TODO output your page here. You may use following sample code. */
			StringBuffer sb = new StringBuffer();
			sb.append("<center><h1>Result For " + searchtextsd + "</h1></center>");
			sb.append("<table class=\"w3-table-all w3-hoverable\" width=\"100px\"align=\"center\">");
			sb.append(
					"<tbody><tr class=\"w3-green\" style=\"height: 40px\"><th>ID</th><th>Visit No</th><th>Patient ID</th><th>Medicine Name</th><th>Dosage</th><th>Prescription Time</th>");
			sb.append("<th>Date Of Visit</th><th>First Name</th><th>Lastname</th><th>Mobile</th><th>EMail</th></tr>");

			Iterator iterator = searchlist.iterator();

			while (iterator.hasNext()) {
				medpresc = (medicinepresc) iterator.next();

				pi = personal.getpersonalInfo(medpresc.getPatientid());
				con = contactdb.getcontact(medpresc.getPatientid());

				sb.append("<tr>");
				sb.append("<td><a target=\"_blank\" href=\"getvisittabdata?idvisitdata=" + medpresc.getIdvisitdata() + "\">"
						+ medpresc.getIdvisitdata() + "</a></td>");

				sb.append("<td>" + medpresc.getVisitno() + "</td>");
				sb.append("<td>" + medpresc.getPatientid() + "</td>");
				sb.append("<td>" + medpresc.getMedicinename() + "</td>");
				sb.append("<td>" + medpresc.getDosage() + "</td>");
				sb.append("<td>" + medpresc.getPresctime() + "</td>");
				sb.append("<td>" + medpresc.getDateofvisit() + "</td>");
				sb.append("<td>" + pi.getFname() + "</td>");
				sb.append("<td>" + pi.getLname() + "</td>");
				sb.append("<td>" + con.getMobile() + "</td>");
				sb.append("<td>" + con.getEmail() + "</td>");
				sb.append("</tr>");
			}
			sb.append("</tbody></table>");
			out.println(sb.toString());
			out.flush();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
