package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.cityDB;

/**
 * Servlet implementation class cityServlet
 */
@WebServlet("/cityServlet")
public class cityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html;charset=UTF-8");
        String country=request.getParameter("country");
        String state=request.getParameter("state");
       StringBuffer sb=new StringBuffer();
       
               
       cityDB cities=new cityDB();
       boolean stateadded=false;
       List<String> citylist=(List<String>)cities.listCity(state);
       try (PrintWriter out = response.getWriter()) {
           /* TODO output your page here. You may use following sample code. */
    	   sb.append("<option>"); 
           sb.append("Select City"); 
           sb.append("</option>");
           
           for (Iterator iterator =citylist.iterator(); iterator.hasNext();){
           String city_name = (String) iterator.next(); 
           sb.append("<option>"); 
           sb.append(city_name); 
           sb.append("</option>");
           stateadded=true;
        }
           if(stateadded)
        out.write(sb.toString());
           else
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
       }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
