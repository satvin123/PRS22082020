package com.prs.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prs.model.contact;
import com.prs.model.eduOccupation;
import com.prs.model.personalInfo;
import com.prs.model.persistence.HibernateUtil;

/**
 * Servlet implementation class personalinfoUpdateServlet
 */
@WebServlet("/personalinfoUpdateServlet")
public class personalinfoUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public personalinfoUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String patientid=request.getParameter("patientId");
		
		
		System.out.println("+++++++++++++++++++++++++++++++"+patientid);
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String DOB=request.getParameter("DOB");
		String gender=request.getParameter("gender");
		String relation=request.getParameter("relation");
		String rname=request.getParameter("rname");
		String married=request.getParameter("married");
		String age=request.getParameter("age");
		
		
		String education=request.getParameter("education");
		String occupation=request.getParameter("occupation");
		String typeofjob=request.getParameter("typeofjob");
		String designation=request.getParameter("designation");
		
		
		String address=request.getParameter("address");
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		String pincode=request.getParameter("pincode");
		String mobile=request.getParameter("mobile");
		String email=request.getParameter("email");
		
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		 
		
		 Transaction tx = null;	
		 try {
			 tx = session.getTransaction();
			 tx.begin();
			 personalInfo pi=new personalInfo();
			 pi.setPersonalinfoid(patientid);
			 pi.setFname(fname);
			 pi.setLname(lname);
			 pi.setDOB(DOB);
			 pi.setGender(gender);
			 pi.setRelation(relation);
			 pi.setRname(rname);
			 pi.setMarried(married);
			 pi.setAge(age);
			 if(!request.getParameter("pid").equals(""))
			 {
				 pi.setId(Integer.parseInt(request.getParameter("pid")));
			 }
			 
			 eduOccupation eduocc=new eduOccupation();
			 eduocc.setPersonalinfoid(patientid);
			 eduocc.setEducation(education);
			 eduocc.setOccupation(occupation);
			 eduocc.setTypeofjob(typeofjob);
			 eduocc.setDesignation(designation);
			 if(!request.getParameter("eid").equals(""))
			 {
				 eduocc.setId(Integer.parseInt(request.getParameter("eid")));
			 }
			 
			 
			 contact cont=new contact();
			 cont.setPersonalinfoid(patientid);
			 cont.setAddress(address);
			 cont.setState(state);
			 cont.setCountry("India");
			 cont.setCity(city);
			 cont.setPincode(pincode);
			 cont.setMobile(mobile);
			 cont.setEmail(email);
			 
			 if(!request.getParameter("cid").equals(""))
			 {
				 cont.setId(Integer.parseInt(request.getParameter("cid")));
			 }
			 
			 
			 	
			 
			 
			 
			 
			 session.update(pi);
			 session.update(eduocc);
			 session.update(cont);
			 tx.commit();
			 response.getWriter().append("<h1>Data Saved Successfully</h1>");
			 response.setHeader("Refresh", "2;url=initial.jsp");
			 
			 
			 
		 } catch (Exception e) {
			 if (tx != null) {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } finally {
			 session.close();
		 }	
		 return;
	}

}
