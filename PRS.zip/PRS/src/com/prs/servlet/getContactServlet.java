package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.contactDB;
import com.prs.dbclass.eduoccupationDB;
import com.prs.model.contact;
import com.prs.model.eduOccupation;

/**
 * Servlet implementation class getContactServlet
 */
@WebServlet("/getContactServlet")
public class getContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getContactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/xml");
        
        contactDB contactDB1 = new contactDB();
       String personalid=request.getParameter("personalinfoid");
       contact contact1 = contactDB1.getcontact(personalid);

       try (PrintWriter out = response.getWriter()) {

           StringBuffer sb = new StringBuffer();
           sb.append("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
           sb.append("<contact>");
           sb.append("<cid>" + contact1.getId() + "</cid>\n");
           sb.append("<personalinfoid>" + contact1.getPersonalinfoid() + "</personalinfoid>\n");
           sb.append("<address>" + contact1.getAddress() + "</address>\n");
           sb.append("<state>" + contact1.getState()+ "</state>\n");
           sb.append("<city>" + contact1.getCity() + "</city>\n");
           sb.append("<pincode>" + contact1.getPincode() + "</pincode>\n");
           sb.append("<mobile>" + contact1.getMobile() + "</mobile>\n");
           sb.append("<email>" + contact1.getEmail() + "</email>\n");
           
           sb.append("</contact>");
           System.out.println(sb.toString());
           out.println(sb.toString());
           out.flush();

       }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
