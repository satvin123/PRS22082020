package com.prs.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prs.model.eduOccupation;
import com.prs.model.personalInfo;
import com.prs.model.persistence.HibernateUtil;

/**
 * Servlet implementation class eduOccupation
 */
@WebServlet("/eduOccupation")
public class eduOccupationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public eduOccupationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String newpatient=request.getParameter("patientidnew1");
		System.out.println(newpatient);
		String education=request.getParameter("education");
		String occupation=request.getParameter("occupation");
		String typeofjob=request.getParameter("typeofjob");
		String designation=request.getParameter("designation");
		
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		 
		
		 Transaction tx = null;	
		 try {
			 tx = session.getTransaction();
			 tx.begin();
			 eduOccupation eduocc=new eduOccupation();
			 eduocc.setPersonalinfoid(newpatient);
			 eduocc.setEducation(education);
			 eduocc.setOccupation(occupation);
			 eduocc.setTypeofjob(typeofjob);
			 eduocc.setDesignation(designation);
			 
			 
			 session.saveOrUpdate(eduocc);		
			 tx.commit();
		 } catch (Exception e) {
			 if (tx != null) {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } finally {
			 session.close();
		 }	
		 return;
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
