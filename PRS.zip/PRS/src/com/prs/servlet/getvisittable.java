package com.prs.servlet;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.personalInfoDB;
import com.prs.dbclass.visitdataDB;
import com.prs.model.personalInfo;

/**
 * Servlet implementation class getvisittable
 */
@WebServlet("/getvisittable")
public class getvisittable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getvisittable() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		visitdataDB visits = new visitdataDB();
		String personalid = request.getParameter("patientId");
		java.util.List<Object[]> visitdata = visits.listvisit(personalid);
		personalInfoDB personaldb= new personalInfoDB();
		personalInfo personal=personaldb.getpersonalInfo(personalid);
		

		StringBuffer sb = new StringBuffer();

		try (PrintWriter out = response.getWriter()) {
			sb.append("<html><head><link rel=\"stylesheet\" type=\"text/css\" href=\"css/w3.css\"><link rel=\"stylesheet\" type=\"text/css\" href=\"css/prsstyle.css\"></head>");
			sb.append("</body><center><h1>Visit Table for Patient</h1></center></br><table class=\"w3-table-all w3-hoverable\" width=\"100px\"align=\"center\">");
			sb.append("<tbody><tr class=\"w3-green\"><th>Visit No</th><th>Patient Name</th><th>Visit Date</th><th>Visit Id</th><th>Patient ID</th>");
			sb.append("</tr></tbody>");

			for (Object[] visitsdata : visitdata) {
				Integer visitid = (Integer) visitsdata[0];
				String visitno = (String) visitsdata[1];
				String visitdate = (String) visitsdata[2];
				sb.append("<tr>");
				sb.append("<td>" + visitno + "</td>");
				sb.append("<td>" + personal.getFname() + " " + personal.getLname() + "</td>");
				sb.append("<td>" + visitdate + "</td>");
				sb.append("<td><a target=\"_blank\" href=\"getvisittabdata?idvisitdata=" + visitid + "\">"+visitid+"</a></td>");
				sb.append("<td>" + personalid + "</td>");
			}
			sb.append("</tbody></table></body></html>");
			out.println(sb.toString());
			out.flush();

			

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
