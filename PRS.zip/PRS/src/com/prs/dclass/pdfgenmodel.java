package com.prs.dclass;

import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class pdfgenmodel {
	
	public static void FixText(String text, int x, int y,PdfWriter writer,int size) {
	    try {
	        PdfContentByte cb = writer.getDirectContent();
	        BaseFont bf = BaseFont.createFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
	        cb.saveState();
	        
	        cb.beginText();
	        cb.moveText(x, y);
	        cb.setFontAndSize(bf, size);
	        cb.showText(text);
	        cb.endText();
	        cb.restoreState();
	    } catch (DocumentException | IOException e) {
	        e.printStackTrace();
	    }
	}
	    
	    public static void FixTextBold(String text, int x, int y,PdfWriter writer,int size) {
	    try {
	        PdfContentByte cb = writer.getDirectContent();
	        BaseFont bf = BaseFont.createFont(BaseFont.TIMES_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
	        cb.saveState();
	        cb.beginText();
	        cb.moveText(x, y);
	        cb.setFontAndSize(bf, size);
	        cb.showText(text);
	        cb.endText();
	        cb.restoreState();
	    } catch (DocumentException | IOException e) {
	        e.printStackTrace();
	    }
	}
	    
	    public void createPdf(String dest) throws IOException, DocumentException {
	        Document document = new Document();
	        PdfWriter.getInstance(document, new FileOutputStream(dest));
	        document.open();
	        PdfPTable table = new PdfPTable(8);
	        for(int aw = 0; aw < 16; aw++){
	            table.addCell("hi");
	        }
	        document.add(table);
	        document.close();
	    }
	    
	    /**
	     * Read the file and returns the byte array
	     * @param file
	     * @return the bytes of the file
	     */
	    public byte[] readFile(String file) {
	        ByteArrayOutputStream bos = null;
	        try {
	            File f = new File(file);
	            FileInputStream fis = new FileInputStream(f);
	            byte[] buffer = new byte[1024];
	            bos = new ByteArrayOutputStream();
	            for (int len; (len = fis.read(buffer)) != -1;) {
	                bos.write(buffer, 0, len);
	            }
	        } catch (FileNotFoundException e) {
	            System.err.println(e.getMessage());
	        } catch (IOException e2) {
	            System.err.println(e2.getMessage());
	        }
	        return bos != null ? bos.toByteArray() : null;
	    }
	    
	    public static byte[] toByteArray(InputStream inputStream) throws IOException {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len;
			while ((len = inputStream.read(buffer)) != -1) {
	                os.write(buffer, 0, len);
			}
			return os.toByteArray();
	    }

}
